import json

def lambda_handler(event, context):
    html = """<!DOCTYPE html>
<html>
<head>
    <title>Security ROI Dashboard - Standalone</title>
    <script src=\"https://cdn.jsdelivr.net/npm/chart.js\"></script>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f7fa; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; text-align: center; border-radius: 8px; margin-bottom: 20px; }
        .metrics { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin: 20px 0; }
        .metric-card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); text-align: center; }
        .metric-value { font-size: 2.5em; font-weight: bold; color: #4f46e5; margin: 10px 0; }
        .chart-container { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin: 20px 0; }
        .status { padding: 15px; margin: 10px 0; border-radius: 8px; background: #d1fae5; color: #065f46; text-align: center; font-weight: bold; }
    </style>
</head>
<body>
    <div class=\"header\">
        <h1>🛡️ Security ROI Dashboard</h1>
        <p>AWS Security Analysis with AgentCore Memory Integration</p>
        <small>Runtime: well_architected_security_comprehensive-YfJAys5DsJ</small>
    </div>

    <div class=\"status\">
        ✅ AgentCore Runtime Active | Memory ID: well_architected_security_comprehensive_mem-kqwwulABUR
    </div>

    <div class=\"metrics\">
        <div class=\"metric-card\">
            <h3>🎯 Security Score</h3>
            <div class=\"metric-value\">85</div>
            <p>Overall security posture</p>
        </div>
        <div class=\"metric-card\">
            <h3>🔍 Total Findings</h3>
            <div class=\"metric-value\">151</div>
            <p>Across 5 security services</p>
        </div>
        <div class=\"metric-card\">
            <h3>💰 Monthly Investment</h3>
            <div class=\"metric-value\">$128</div>
            <p>Security services cost</p>
        </div>
        <div class=\"metric-card\">
            <h3>📈 ROI</h3>
            <div class=\"metric-value\">23,337%</div>
            <p>Return on investment</p>
        </div>
    </div>

    <div class=\"chart-container\">
        <h3>Security Findings by Severity</h3>
        <canvas id=\"findingsChart\" width=\"400\" height=\"200\"></canvas>
    </div>

    <div class=\"chart-container\">
        <h3>Monthly Cost Breakdown by Service</h3>
        <canvas id=\"costChart\" width=\"400\" height=\"200\"></canvas>
    </div>

    <script>
        // Findings Chart
        new Chart(document.getElementById('findingsChart'), {
            type: 'doughnut',
            data: {
                labels: ['Critical', 'High', 'Medium', 'Low'],
                datasets: [{
                    data: [12, 34, 67, 38],
                    backgroundColor: ['#dc2626', '#ea580c', '#d97706', '#65a30d'],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'bottom' }
                }
            }
        });

        // Cost Chart
        new Chart(document.getElementById('costChart'), {
            type: 'bar',
            data: {
                labels: ['GuardDuty', 'Inspector', 'Security Hub', 'Macie', 'Access Analyzer'],
                datasets: [{
                    label: 'Monthly Cost ($)',
                    data: [45, 25, 15, 35, 8],
                    backgroundColor: '#4f46e5',
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });

        // Status indicator
        setInterval(() => {
            document.querySelector('.status').innerHTML = 
                `✅ AgentCore Runtime Active | Last Updated: ${new Date().toLocaleTimeString()}`;
        }, 30000);
    </script>
</body>
</html>
"""
    
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'text/html',
            'Access-Control-Allow-Origin': '*'
        },
        'body': html
    }
