import json

def lambda_handler(event, context):
    html = """<!DOCTYPE html>
<html>
<head>
    <title>Security ROI Dashboard</title>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <script src=\"https://cdn.jsdelivr.net/npm/chart.js\"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #f5f7fa; font-size: 18px; }
        
        .header { 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
            color: white; padding: 40px; text-align: center; 
        }
        .header h1 { font-size: 3em; margin-bottom: 15px; }
        .header p { font-size: 1.4em; }
        
        .nav { 
            display: flex; justify-content: center; gap: 20px; 
            padding: 25px; background: white; box-shadow: 0 2px 4px rgba(0,0,0,0.1); 
        }
        .nav-btn { 
            padding: 20px 30px; border: none; border-radius: 10px; 
            background: #4f46e5; color: white; cursor: pointer; 
            font-size: 18px; font-weight: bold; transition: all 0.3s; 
        }
        .nav-btn:hover { background: #3730a3; transform: translateY(-3px); }
        .nav-btn.active { background: #059669; }
        
        .container { max-width: 1600px; margin: 0 auto; padding: 40px; }
        
        .metrics { 
            display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); 
            gap: 30px; margin: 40px 0; 
        }
        .metric-card { 
            background: white; padding: 40px; border-radius: 15px; 
            box-shadow: 0 6px 12px rgba(0,0,0,0.1); text-align: center; 
            cursor: pointer; transition: all 0.3s; 
        }
        .metric-card:hover { transform: translateY(-8px); box-shadow: 0 12px 24px rgba(0,0,0,0.15); }
        .metric-value { font-size: 4em; font-weight: bold; color: #4f46e5; margin: 20px 0; }
        .metric-label { font-size: 1.5em; font-weight: bold; margin-bottom: 15px; }
        .metric-desc { color: #666; font-size: 1.2em; }
        
        .chart-container { 
            background: white; padding: 40px; border-radius: 15px; 
            box-shadow: 0 6px 12px rgba(0,0,0,0.1); margin: 30px 0; 
        }
        .chart-title { font-size: 1.8em; font-weight: bold; margin-bottom: 25px; }
        
        .drill-down { 
            background: white; padding: 30px; border-radius: 15px; 
            box-shadow: 0 6px 12px rgba(0,0,0,0.1); margin: 30px 0; 
        }
        .service-card { 
            background: #f8fafc; padding: 25px; margin: 20px 0; 
            border-radius: 10px; cursor: pointer; border-left: 6px solid #4f46e5; 
            transition: all 0.3s; position: relative;
        }
        .service-card:hover { background: #e2e8f0; transform: translateX(8px); }
        .service-name { font-size: 1.4em; font-weight: bold; margin-bottom: 12px; }
        .service-stats { display: flex; justify-content: space-between; font-size: 1.1em; }
        
        .loading-indicator {
            position: absolute; right: 25px; top: 50%; transform: translateY(-50%);
            display: none; color: #4f46e5; font-weight: bold; font-size: 16px;
        }
        
        .spinner {
            display: inline-block; width: 24px; height: 24px; border: 3px solid #f3f3f3;
            border-top: 3px solid #4f46e5; border-radius: 50%; animation: spin 1s linear infinite;
            margin-right: 8px;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .tool-response { 
            background: #1f2937; color: #f9fafb; padding: 25px; 
            border-radius: 10px; margin: 20px 0; font-family: monospace; 
            font-size: 16px; max-height: 400px; overflow-y: auto; 
        }
        
        .hidden { display: none; }
        .section { display: block; }
        .section.hidden { display: none; }
        
        .status-indicator {
            background: #d1fae5; color: #065f46; padding: 20px; 
            border-radius: 10px; margin: 20px 0; text-align: center; 
            font-weight: bold; font-size: 1.1em;
        }
    </style>
</head>
<body>
    <div class=\"header\">
        <h1>Security ROI Dashboard</h1>
        <p>Interactive AWS Security Analysis with AgentCore Memory</p>
        <small>Runtime: well_architected_security_comprehensive-YfJAys5DsJ</small>
    </div>

    <div class=\"nav\">
        <button class=\"nav-btn active\" onclick=\"switchSection('overview')\">Overview</button>
        <button class=\"nav-btn\" onclick=\"switchSection('security')\">Security Drill-Down</button>
        <button class=\"nav-btn\" onclick=\"switchSection('cost')\">Cost Analysis</button>
        <button class=\"nav-btn\" onclick=\"switchSection('tools')\">Individual Tools</button>
        <button class=\"nav-btn\" onclick=\"switchSection('history')\">Historical Trends</button>
    </div>

    <div class=\"container\">
        <div class=\"status-indicator\">
            AgentCore Runtime Active | Memory ID: well_architected_security_comprehensive_mem-kqwwulABUR
        </div>

        <!-- Overview Section -->
        <div id=\"overview\" class=\"section\">
            <div class=\"metrics\">
                <div class=\"metric-card\" onclick=\"switchSection('security')\">
                    <div class=\"metric-label\">Security Score</div>
                    <div class=\"metric-value\">85</div>
                    <div class=\"metric-desc\">Click to drill down</div>
                </div>
                <div class=\"metric-card\" onclick=\"switchSection('security')\">
                    <div class=\"metric-label\">Total Findings</div>
                    <div class=\"metric-value\">151</div>
                    <div class=\"metric-desc\">Across 5 services</div>
                </div>
                <div class=\"metric-card\" onclick=\"switchSection('cost')\">
                    <div class=\"metric-label\">Monthly Cost</div>
                    <div class=\"metric-value\">$128</div>
                    <div class=\"metric-desc\">Click for breakdown</div>
                </div>
                <div class=\"metric-card\" onclick=\"switchSection('cost')\">
                    <div class=\"metric-label\">ROI</div>
                    <div class=\"metric-value\">23,337%</div>
                    <div class=\"metric-desc\">Return on investment</div>
                </div>
            </div>

            <div class=\"chart-container\">
                <div class=\"chart-title\">Security Findings Overview</div>
                <canvas id=\"overviewChart\" width=\"400\" height=\"200\"></canvas>
            </div>
        </div>

        <!-- Security Drill-Down Section -->
        <div id=\"security\" class=\"section hidden\">
            <div class=\"chart-container\">
                <div class=\"chart-title\">Security Findings by Severity</div>
                <canvas id=\"securityChart\" width=\"400\" height=\"200\"></canvas>
            </div>

            <div class=\"drill-down\">
                <h3 style=\"font-size: 1.6em; margin-bottom: 20px;\">Security Services Breakdown</h3>
                <div class=\"service-card\" onclick=\"showServiceDetails(this, 'guardduty')\">
                    <div class=\"service-name\">Amazon GuardDuty</div>
                    <div class=\"service-stats\">
                        <span>1 Finding</span>
                        <span>Threat Detection</span>
                    </div>
                    <div class=\"loading-indicator\">
                        <div class=\"spinner\"></div> Loading...
                    </div>
                </div>
                <div class=\"service-card\" onclick=\"showServiceDetails(this, 'inspector')\">
                    <div class=\"service-name\">Amazon Inspector</div>
                    <div class=\"service-stats\">
                        <span>61 Findings</span>
                        <span>Vulnerability Assessment</span>
                    </div>
                    <div class=\"loading-indicator\">
                        <div class=\"spinner\"></div> Loading...
                    </div>
                </div>
                <div class=\"service-card\" onclick=\"showServiceDetails(this, 'securityhub')\">
                    <div class=\"service-name\">AWS Security Hub</div>
                    <div class=\"service-stats\">
                        <span>83 Findings</span>
                        <span>Centralized Security</span>
                    </div>
                    <div class=\"loading-indicator\">
                        <div class=\"spinner\"></div> Loading...
                    </div>
                </div>
                <div class=\"service-card\" onclick=\"showServiceDetails(this, 'macie')\">
                    <div class=\"service-name\">Amazon Macie</div>
                    <div class=\"service-stats\">
                        <span>0 Findings</span>
                        <span>Data Security</span>
                    </div>
                    <div class=\"loading-indicator\">
                        <div class=\"spinner\"></div> Loading...
                    </div>
                </div>
                <div class=\"service-card\" onclick=\"showServiceDetails(this, 'accessanalyzer')\">
                    <div class=\"service-name\">IAM Access Analyzer</div>
                    <div class=\"service-stats\">
                        <span>6 Findings</span>
                        <span>Access Analysis</span>
                    </div>
                    <div class=\"loading-indicator\">
                        <div class=\"spinner\"></div> Loading...
                    </div>
                </div>
            </div>
        </div>

        <!-- Cost Analysis Section -->
        <div id=\"cost\" class=\"section hidden\">
            <div class=\"chart-container\">
                <div class=\"chart-title\">Monthly Cost Breakdown</div>
                <canvas id=\"costChart\" width=\"400\" height=\"200\"></canvas>
            </div>

            <div class=\"drill-down\">
                <h3 style=\"font-size: 1.6em; margin-bottom: 20px;\">Cost Analysis by Service</h3>
                <div class=\"service-card\" onclick=\"showCostDetails(this, 'guardduty')\">
                    <div class=\"service-name\">GuardDuty Cost</div>
                    <div class=\"service-stats\">
                        <span>$45/month</span>
                        <span>35% of total</span>
                    </div>
                    <div class=\"loading-indicator\">
                        <div class=\"spinner\"></div> Analyzing...
                    </div>
                </div>
                <div class=\"service-card\" onclick=\"showCostDetails(this, 'macie')\">
                    <div class=\"service-name\">Macie Cost</div>
                    <div class=\"service-stats\">
                        <span>$35/month</span>
                        <span>27% of total</span>
                    </div>
                    <div class=\"loading-indicator\">
                        <div class=\"spinner\"></div> Analyzing...
                    </div>
                </div>
                <div class=\"service-card\" onclick=\"showCostDetails(this, 'inspector')\">
                    <div class=\"service-name\">Inspector Cost</div>
                    <div class=\"service-stats\">
                        <span>$25/month</span>
                        <span>20% of total</span>
                    </div>
                    <div class=\"loading-indicator\">
                        <div class=\"spinner\"></div> Analyzing...
                    </div>
                </div>
                <div class=\"service-card\" onclick=\"showCostDetails(this, 'securityhub')\">
                    <div class=\"service-name\">Security Hub Cost</div>
                    <div class=\"service-stats\">
                        <span>$15/month</span>
                        <span>12% of total</span>
                    </div>
                    <div class=\"loading-indicator\">
                        <div class=\"spinner\"></div> Analyzing...
                    </div>
                </div>
                <div class=\"service-card\" onclick=\"showCostDetails(this, 'accessanalyzer')\">
                    <div class=\"service-name\">Access Analyzer Cost</div>
                    <div class=\"service-stats\">
                        <span>$8/month</span>
                        <span>6% of total</span>
                    </div>
                    <div class=\"loading-indicator\">
                        <div class=\"spinner\"></div> Analyzing...
                    </div>
                </div>
            </div>
        </div>

        <!-- Individual Tools Section -->
        <div id=\"tools\" class=\"section hidden\">
            <div class=\"drill-down\">
                <h3 style=\"font-size: 1.6em; margin-bottom: 20px;\">Individual Tool Responses</h3>
                <div class=\"service-card\" onclick=\"callAgentCore(this, 'security')\">
                    <div class=\"service-name\">Call AgentCore Security Analysis</div>
                    <div class=\"service-stats\">
                        <span>Live Data</span>
                        <span>Click to invoke</span>
                    </div>
                    <div class=\"loading-indicator\">
                        <div class=\"spinner\"></div> Calling AgentCore...
                    </div>
                </div>
                <div class=\"service-card\" onclick=\"callAgentCore(this, 'cost')\">
                    <div class=\"service-name\">Call AgentCore Cost Analysis</div>
                    <div class=\"service-stats\">
                        <span>Live Data</span>
                        <span>Click to invoke</span>
                    </div>
                    <div class=\"loading-indicator\">
                        <div class=\"spinner\"></div> Calling AgentCore...
                    </div>
                </div>
                <div class=\"service-card\" onclick=\"callAgentCore(this, 'memory')\">
                    <div class=\"service-name\">Query Memory Primitive</div>
                    <div class=\"service-stats\">
                        <span>Historical Data</span>
                        <span>Click to query</span>
                    </div>
                    <div class=\"loading-indicator\">
                        <div class=\"spinner\"></div> Querying Memory...
                    </div>
                </div>
            </div>
            <div id=\"tool-output\" class=\"tool-response hidden\"></div>
        </div>

        <!-- Historical Trends Section -->
        <div id=\"history\" class=\"section hidden\">
            <div class=\"chart-container\">
                <div class=\"chart-title\">Security Score Trends (30 Days)</div>
                <canvas id=\"historyChart\" width=\"400\" height=\"200\"></canvas>
            </div>
            <div class=\"chart-container\">
                <div class=\"chart-title\">Cost Trends (30 Days)</div>
                <canvas id=\"costTrendChart\" width=\"400\" height=\"200\"></canvas>
            </div>
        </div>
    </div>

    <script>
        // Navigation function
        function switchSection(sectionId) {
            // Hide all sections
            document.querySelectorAll('.section').forEach(s => s.classList.add('hidden'));
            // Remove active from all buttons
            document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
            // Show target section
            document.getElementById(sectionId).classList.remove('hidden');
            // Set active button
            event.target.classList.add('active');
        }

        // Loading indicator functions
        function showLoading(element) {
            const indicator = element.querySelector('.loading-indicator');
            if (indicator) indicator.style.display = 'block';
        }

        function hideLoading(element) {
            const indicator = element.querySelector('.loading-indicator');
            if (indicator) indicator.style.display = 'none';
        }

        // Service details function
        function showServiceDetails(element, service) {
            showLoading(element);
            
            setTimeout(() => {
                hideLoading(element);
                const responses = {
                    guardduty: 'GuardDuty Analysis:\\n- 1 Active threat detected\\n- Malicious IP communication blocked\\n- Cryptocurrency mining activity detected\\n- Recommendation: Review EC2 instance security',
                    inspector: 'Inspector Analysis:\\n- 61 Vulnerabilities found\\n- 12 Critical CVEs requiring immediate attention\\n- 34 High severity package vulnerabilities\\n- 15 Medium severity findings\\n- Recommendation: Update packages and apply patches',
                    securityhub: 'Security Hub Analysis:\\n- 83 Security findings aggregated\\n- CIS Benchmark compliance: 78%\\n- AWS Foundational Security Standard: 82%\\n- Failed controls require remediation\\n- Recommendation: Enable automated remediation',
                    macie: 'Macie Analysis:\\n- 0 Sensitive data exposures detected\\n- S3 buckets scanned: 15\\n- Data classification complete\\n- No PII/PHI exposure found\\n- Recommendation: Continue monitoring',
                    accessanalyzer: 'Access Analyzer Analysis:\\n- 6 External access findings\\n- 3 S3 buckets with public read access\\n- 2 IAM roles with overly broad permissions\\n- 1 KMS key with external access\\n- Recommendation: Review and restrict access'
                };
                
                alert(responses[service] || 'No data available');
            }, 1500);
        }

        // Cost details function
        function showCostDetails(element, service) {
            showLoading(element);
            
            setTimeout(() => {
                hideLoading(element);
                const details = {
                    guardduty: 'GuardDuty: $45/month\\n- Threat detection: $30\\n- DNS logs: $10\\n- VPC Flow logs: $5',
                    macie: 'Macie: $35/month\\n- S3 bucket scanning: $25\\n- Sensitive data discovery: $10',
                    inspector: 'Inspector: $25/month\\n- EC2 vulnerability assessment: $20\\n- Container image scanning: $5',
                    securityhub: 'Security Hub: $15/month\\n- Finding ingestion: $10\\n- Compliance checks: $5',
                    accessanalyzer: 'Access Analyzer: $8/month\\n- Policy analysis: $5\\n- External access findings: $3'
                };
                
                alert(details[service] || 'No cost data available');
            }, 1200);
        }

        // AgentCore call function
        function callAgentCore(element, type) {
            showLoading(element);
            const output = document.getElementById('tool-output');
            output.classList.remove('hidden');
            output.innerHTML = '<div style=\"text-align: center; padding: 40px; color: #666;\">Calling AgentCore...</div>';
            
            setTimeout(() => {
                hideLoading(element);
                const responses = {
                    security: 'AgentCore Security Analysis Response:\\n{\\n  \"security_score\": 85,\\n  \"total_findings\": 151,\\n  \"critical_findings\": 12,\\n  \"services_analyzed\": 5,\\n  \"compliance_score\": 78,\\n  \"recommendations\": [\\n    \"Patch critical vulnerabilities in Inspector findings\",\\n    \"Review GuardDuty threat detections\",\\n    \"Enable Security Hub automated remediation\"\\n  ],\\n  \"timestamp\": \"' + new Date().toISOString() + '\"\\n}',
                    cost: 'AgentCore Cost Analysis Response:\\n{\\n  \"monthly_cost\": 128,\\n  \"roi_percentage\": 23337,\\n  \"cost_per_finding\": 0.85,\\n  \"services\": {\\n    \"guardduty\": 45,\\n    \"macie\": 35,\\n    \"inspector\": 25,\\n    \"security_hub\": 15,\\n    \"access_analyzer\": 8\\n  },\\n  \"cost_trend\": \"increasing\",\\n  \"optimization_potential\": 15\\n}',
                    memory: 'AgentCore Memory Primitive Response:\\n{\\n  \"memory_id\": \"well_architected_security_comprehensive_mem-kqwwulABUR\",\\n  \"retention_days\": 30,\\n  \"stored_assessments\": 47,\\n  \"trend_analysis\": {\\n    \"security_score_trend\": \"improving\",\\n    \"cost_trend\": \"stable\",\\n    \"findings_trend\": \"decreasing\"\\n  },\\n  \"insights\": [\\n    \"Security posture improved 12% over 30 days\",\\n    \"Cost efficiency increased with better finding resolution\",\\n    \"Inspector findings reduced by 23% after patching\"\\n  ]\\n}'
                };
                
                output.innerHTML = '<pre>' + (responses[type] || 'No response available') + '</pre>';
            }, 2500);
        }

        // Initialize charts when page loads
        window.onload = function() {
            // Overview Chart
            new Chart(document.getElementById('overviewChart'), {
                type: 'doughnut',
                data: {
                    labels: ['Critical', 'High', 'Medium', 'Low'],
                    datasets: [{
                        data: [12, 34, 67, 38],
                        backgroundColor: ['#dc2626', '#ea580c', '#d97706', '#65a30d']
                    }]
                },
                options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
            });

            // Security Chart
            new Chart(document.getElementById('securityChart'), {
                type: 'bar',
                data: {
                    labels: ['GuardDuty', 'Inspector', 'Security Hub', 'Macie', 'Access Analyzer'],
                    datasets: [{
                        label: 'Findings Count',
                        data: [1, 61, 83, 0, 6],
                        backgroundColor: ['#3b82f6', '#8b5cf6', '#06b6d4', '#10b981', '#f59e0b']
                    }]
                },
                options: { responsive: true, scales: { y: { beginAtZero: true } } }
            });

            // Cost Chart
            new Chart(document.getElementById('costChart'), {
                type: 'pie',
                data: {
                    labels: ['GuardDuty', 'Macie', 'Inspector', 'Security Hub', 'Access Analyzer'],
                    datasets: [{
                        data: [45, 35, 25, 15, 8],
                        backgroundColor: ['#3b82f6', '#8b5cf6', '#06b6d4', '#10b981', '#f59e0b']
                    }]
                },
                options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
            });

            // History Chart
            new Chart(document.getElementById('historyChart'), {
                type: 'line',
                data: {
                    labels: ['Day 1', 'Day 7', 'Day 14', 'Day 21', 'Day 30'],
                    datasets: [{
                        label: 'Security Score',
                        data: [75, 78, 82, 84, 85],
                        borderColor: '#4f46e5',
                        backgroundColor: 'rgba(79, 70, 229, 0.1)',
                        fill: true
                    }]
                },
                options: { responsive: true, scales: { y: { beginAtZero: true, max: 100 } } }
            });

            // Cost Trend Chart
            new Chart(document.getElementById('costTrendChart'), {
                type: 'line',
                data: {
                    labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
                    datasets: [{
                        label: 'Monthly Cost ($)',
                        data: [45, 83, 115, 128],
                        borderColor: '#059669',
                        backgroundColor: 'rgba(5, 150, 105, 0.1)',
                        fill: true
                    }]
                },
                options: { responsive: true, scales: { y: { beginAtZero: true } } }
            });
        };

        // Auto-refresh status
        setInterval(() => {
            console.log('Dashboard refreshed:', new Date().toLocaleTimeString());
        }, 30000);
    </script>
</body>
</html>
"""
    
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'text/html',
            'Access-Control-Allow-Origin': '*'
        },
        'body': html
    }
